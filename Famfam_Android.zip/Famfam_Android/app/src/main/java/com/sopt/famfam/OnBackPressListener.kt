package com.sopt.famfam

interface OnBackPressListener {

    fun onBackPressed(): Boolean
}