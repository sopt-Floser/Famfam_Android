package com.sopt.famfam.adapter.item

import java.time.LocalDateTime


data class AnniversaryItem(var title : String, var date : LocalDateTime, var exDate : String, var type : Int){

}