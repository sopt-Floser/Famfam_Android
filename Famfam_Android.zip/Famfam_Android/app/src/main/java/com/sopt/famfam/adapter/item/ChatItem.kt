package com.sopt.famfam.adapter.item


data class ChatItem(var id:String, var name : String, var time : String, var type : Int){

}