package com.sopt.famfam.adapter.item


data class DemoItem(var id:String,var name : String){

}