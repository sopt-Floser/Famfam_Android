package com.sopt.famfam.adapter.item

data class FamilyListItem(var id : Int, var img : String, var name : String  ){}