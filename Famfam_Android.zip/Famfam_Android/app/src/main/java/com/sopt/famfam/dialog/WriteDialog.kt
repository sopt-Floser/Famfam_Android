package com.sopt.famfam.dialog

import android.app.Dialog
import android.content.Context

class WriteDialog(context: Context?,var title :String, var content: String) : Dialog(context) {

}

