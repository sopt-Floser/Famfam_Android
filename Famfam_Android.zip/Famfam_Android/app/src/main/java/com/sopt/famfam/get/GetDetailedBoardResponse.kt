import com.sopt.famfam.data.BoardData

data class GetDetailedBoardResponse(
        val status : String,
        val message : String,
        val data : BoardData
)
