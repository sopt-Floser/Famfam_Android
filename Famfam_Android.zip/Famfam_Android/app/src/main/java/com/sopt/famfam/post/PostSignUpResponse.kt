
data class PostSignUpResponse(
        val status : String,
        val message : String
)
