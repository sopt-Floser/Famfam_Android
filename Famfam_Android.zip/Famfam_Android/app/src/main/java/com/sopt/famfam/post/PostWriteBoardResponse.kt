
data class PostWriteBoardResponse(
        val status : String,
        val message : String
)